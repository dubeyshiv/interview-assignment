import { Component, ViewChild } from "@angular/core";
import { Subject } from "rxjs";
import { Child } from "./child/child.component";

@Component({
    selector: 'parent',
    templateUrl: './parent.component.html'
})
export class Parent {
    constructor() {}

    @ViewChild('child') child: Child;

    submitOutput() {
        console.log('Id', this.child.id);
        this.child.formValue.subscribe(value=>{
            console.log(value);
        })
    }
}