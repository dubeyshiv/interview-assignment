import { AfterViewInit, Component, EventEmitter, Input, Output } from "@angular/core";
import { Subject } from "rxjs";

@Component({
    selector: 'child',
    templateUrl: './child.component.html'
})
export class Child implements AfterViewInit{
    constructor() {}

    @Input() id: number;
    @Output() submit = new EventEmitter<boolean>();
    formValue: Subject<boolean>;

    ngAfterViewInit() {
        this.formValue.next(true);
    }

}