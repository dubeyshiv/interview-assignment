import { Component, OnInit } from "@angular/core";

@Component({
    selector: 'search',
    templateUrl: './search.component.html'
})
export class SearchComponent implements OnInit {
    constructor(){}
    listData: any[] = [];
    public searchText: any = 'Orr';
    filteredData: any[] = [];

    ngOnInit() {
        this.listData = this.getTestData();
        this.filteredData = this.getTestData();
    }

    search(value) {
            this.filteredData = this.listData.filter(list=> {
                if (list.name.includes(value)) {
                    return list;
                }
            });
    }
    getTestData() {
        return [{"id":"5f478ace4ecc56b8fc2fd5d0","isActive":false,"picture":"http://placehold.it/32x32","name":"Orr Pruitt","email":"Davis.Schmidt@example.com","phone":"+1 (825) 448-3195"},{"id":"5f478acef41273690673c937","isActive":true,"picture":"http://placehold.it/32x32","name":"Roslyn Stuart","email":"Sarah.Rosales@example.com","phone":"+1 (910) 467-3569"},{"id":"5f478ace650a6ed68b3fe44a","isActive":false,"picture":"http://placehold.it/32x32","name":"Durham Prince","email":"Guthrie.Moses@example.com","phone":"+1 (866) 581-3918"},{"id":"5f478ace19d2298adbbc7a4f","isActive":true,"picture":"http://placehold.it/32x32","name":"Christine Hahn","email":"Kristin.Pate@example.com","phone":"+1 (855) 590-2321"},{"id":"5f478acee829bddb4b6ed16e","isActive":false,"picture":"http://placehold.it/32x32","name":"Tara Gill","email":"Calderon.Mayo@example.com","phone":"+1 (910) 492-3751"},{"id":"5f478aced00df1b567cb202b","isActive":false,"picture":"http://placehold.it/32x32","name":"Gillespie Richards","email":"Shelly.Fulton@example.com","phone":"+1 (889) 594-3171"},{"id":"5f478aceffb5fb0f198c47da","isActive":true,"picture":"http://placehold.it/32x32","name":"Celina Hebert","email":"Vang.Leblanc@example.com","phone":"+1 (886) 438-2289"},{"id":"5f478ace37a0d7761f96c459","isActive":false,"picture":"http://placehold.it/32x32","name":"Mills Nielsen","email":"Arlene.Santos@example.com","phone":"+1 (945) 599-3756"},{"id":"5f478ace62a4d0f337bcb78e","isActive":true,"picture":"http://placehold.it/32x32","name":"Alexis Mays","email":"Mullen.Cain@example.com","phone":"+1 (876) 487-2599"},{"id":"5f478ace2ebe309f556cc904","isActive":false,"picture":"http://placehold.it/32x32","name":"Aguilar Joyce","email":"Ivy.Whitehead@example.com","phone":"+1 (838) 470-2654"},{"id":"5f478ace5c817dab129c26e3","isActive":true,"picture":"http://placehold.it/32x32","name":"Carver Fields","email":"Yang.Cantrell@example.com","phone":"+1 (864) 458-3909"},{"id":"5f478aced775e0e49313db0f","isActive":true,"picture":"http://placehold.it/32x32","name":"Vazquez Carlson","email":"Avery.Vaughn@example.com","phone":"+1 (892) 492-3779"},{"id":"5f478acef1721e081f862202","isActive":false,"picture":"http://placehold.it/32x32","name":"Liz Randolph","phone":"+1 (882) 598-3098"}];
    }
}
